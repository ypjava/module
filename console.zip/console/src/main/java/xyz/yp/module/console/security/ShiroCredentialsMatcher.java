package xyz.yp.module.console.security;

public class ShiroCredentialsMatcher {
}
