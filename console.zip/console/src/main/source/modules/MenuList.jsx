import Workbench from './Workbench.jsx';
import UserList from './UserList.jsx';
import UserAdd from './UserAdd.jsx';

module.exports = { Workbench, UserList, UserAdd };