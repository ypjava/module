import React from 'react';
import { Link } from 'react-router-dom';
import { Table, Icon, Divider } from 'antd';

class Workbench extends React.Component {
    constructor(props) {
        super(props);
    }

    componentWillMount() {

    }

    componentWillUnmount() {

    }

    render() {
        return (
            <div>
                首页-工作台
            </div>
        );
    }
}

module.exports = Workbench;